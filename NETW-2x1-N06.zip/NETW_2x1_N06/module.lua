-- =====================================================
--  WiFi Speed Graph (Elysium Official - Safe Version)
-- =====================================================

local M = {}

-- =====================================================
-- Config
-- =====================================================
local CARD_W = 282
local CARD_H = 134
local RADIUS = 15

local HISTORY_SIZE = 60
local MIN_SCALE_KB = 10

-- Graph Position
local GRAPH_X = 12
local GRAPH_Y = 28

-- Font Config
local LABEL_FONT = "Roboto Condensed"
local LABEL_SIZE = 8

local VALUE_FONT = "Roboto"
local VALUE_SIZE = 10

-- Text Position
local UP_X, UP_Y = 210, 35
local UP_VAL_Y = 46

local UP_TOTAL_X, UP_TOTAL_Y = 210, 58
local UP_TOTAL_VAL_Y = 69

local DOWN_X, DOWN_Y = 210, 85
local DOWN_VAL_Y = 96

local DOWN_TOTAL_X, DOWN_TOTAL_Y = 210, 108
local DOWN_TOTAL_VAL_Y = 119

-- =====================================================
-- Color Config
-- =====================================================
local HOME = os.getenv("HOME") or ""
local COLOR_CONF = HOME .. "/.config/conky/Elysium/modules/NETW_2x1_N06/color.conf"

local color_map = {
    up   = "red",
    down = "blue"
}

local function load_color_conf()
    local f = io.open(COLOR_CONF, "r")
    if not f then return end

    for line in f:lines() do
        line = line:gsub("^%s+", ""):gsub("%s+$", "")

        if line ~= "" and not line:match("^#") and not line:match("^%-%-") then
            local k,v = line:match("(%w+)%s*=%s*(%w+)")
            if k and v then
                color_map[k] = v
            end
        end
    end

    f:close()
end

load_color_conf()

-- =====================================================
-- Buffers
-- =====================================================
local down_hist = {}
local up_hist   = {}

-- =====================================================
-- HEX → RGBA
-- =====================================================
local function rgb_to_r_g_b(colour, alpha)
    if type(colour) == "string" then
        colour = tonumber(colour:gsub("#","0x"))
    end
    return ((colour / 0x10000) % 0x100) / 255.,
           ((colour / 0x100) % 0x100) / 255.,
           (colour % 0x100) / 255.,
           alpha
end

-- =====================================================
-- Resolve Interface
-- =====================================================
local function resolve_iface(ctx)
    return ctx and ctx.runtime and ctx.runtime.net_iface
end

-- =====================================================
-- Connection Detail
-- =====================================================
local function get_connection_detail(ctx)

    local iface = ctx.runtime.net_iface
    local ntype = ctx.runtime.net_type or "none"

    if not iface then return "Network Unavailable" end

    if ntype == "wifi" then
        local ssid = conky_parse("${exec iwgetid -r 2>/dev/null}")
        return (ssid ~= "" and ("Wi-Fi : " .. ssid)) or "Wi-Fi"
    end

    if ntype == "lan" then return "Wired Connection" end
    if ntype == "usb" then return "USB Tethering" end

    return "Network Unavailable"
end

-- =====================================================
-- Rounded Rectangle
-- =====================================================
local function rounded_rect(cr, x, y, w, h, r)
    if r > h/2 then r = h/2 end
    if r > w/2 then r = w/2 end

    cairo_new_sub_path(cr)
    cairo_arc(cr, x + w - r, y + r, r, -math.pi/2, 0)
    cairo_arc(cr, x + w - r, y + h - r, r, 0, math.pi/2)
    cairo_arc(cr, x + r, y + h - r, r, math.pi/2, math.pi)
    cairo_arc(cr, x + r, y + r, r, math.pi, 3*math.pi/2)
    cairo_close_path(cr)
end

-- =====================================================
-- Container
-- =====================================================
function M.draw_rect(ctx)
    local cr, s, theme = ctx.cr, ctx.s, ctx.theme
    local r,g,b,a = rgb_to_r_g_b(theme.bg_alt, 1)

    cairo_set_source_rgba(cr, r,g,b,a)
    rounded_rect(cr, ctx.x, ctx.y, s(CARD_W), s(CARD_H), s(RADIUS))
    cairo_fill(cr)
end

-- =====================================================
-- Update (FIXED)
-- =====================================================
function M.update(ctx)

    if not conky_window then return end

    local iface = resolve_iface(ctx)

    local down, up = 0, 0

    if iface then
        down = tonumber(conky_parse('${downspeedf ' .. iface .. '}')) or 0
        up   = tonumber(conky_parse('${upspeedf ' .. iface .. '}')) or 0
    end

    table.insert(down_hist, 1, down)
    table.insert(up_hist,   1, up)

    if #down_hist > HISTORY_SIZE then table.remove(down_hist) end
    if #up_hist   > HISTORY_SIZE then table.remove(up_hist)   end
end

-- =====================================================
-- Autoscale
-- =====================================================
local function autoscale(hist)
    local max = 0
    for _,v in ipairs(hist) do
        if v > max then max = v end
    end
    return math.max(max, MIN_SCALE_KB)
end

-- =====================================================
-- Graph
-- =====================================================
function M.draw_graph(ctx)

    local cr, s, theme = ctx.cr, ctx.s, ctx.theme

    local w, h = s(188), s(94)
    local x = ctx.x + s(GRAPH_X)
    local y = ctx.y + s(GRAPH_Y)

    local mid      = math.floor(y + h / 2) + 0.5
    local half_h   = (h / 2) - 0.6
    local mid_up   = mid - 0.5
    local mid_down = mid + 0.5

    local r,g,b,_ = rgb_to_r_g_b(theme.bar_bg_alt,1)
    cairo_set_source_rgba(cr,r,g,b,0.6)
    rounded_rect(cr,x,y,w,h,s(6))
    cairo_fill(cr)

    local max_up   = autoscale(up_hist)
    local max_down = autoscale(down_hist)
    local step     = w / (HISTORY_SIZE - 1)

    local function draw_hist(hist, color, base_y, direction, scale)
        if #hist < 2 then return end

        local r,g,b,_ = rgb_to_r_g_b(color,1)

        cairo_move_to(cr, x + w, base_y)

        for i,v in ipairs(hist) do
            local pct = math.min(v / scale, 0.95)
            local px  = x + w - (i-1)*step
            local py  = base_y + direction * pct * half_h
            cairo_line_to(cr, px, py)
        end

        cairo_line_to(cr, x, base_y)
        cairo_close_path(cr)

        cairo_set_source_rgba(cr,r,g,b,0.15)
        cairo_fill_preserve(cr)

        cairo_set_source_rgba(cr,r,g,b,1)
        cairo_set_line_width(cr,1.2)
        cairo_stroke(cr)
    end

    local col_down = theme[color_map.down] or theme.blue
    local col_up   = theme[color_map.up]   or theme.red

    draw_hist(down_hist, col_down, mid_down,  1,  max_down)
    draw_hist(up_hist,   col_up,   mid_up,   -1,  max_up)

    ctx.graph_x = x
    ctx.graph_y = y
    ctx.graph_h = h
end

-- =====================================================
-- Text (FIXED)
-- =====================================================
function M.draw_text(ctx)

    local cr, s, theme = ctx.cr, ctx.s, ctx.theme

    -- Connection
    local text_str = get_connection_detail(ctx)

    cairo_select_font_face(cr, LABEL_FONT, CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)
    cairo_set_font_size(cr, s(10))

    local r,g,b,_ = rgb_to_r_g_b(theme.text_alt,1)
    cairo_set_source_rgba(cr,r,g,b,1)

    cairo_move_to(cr, ctx.x + s(15), ctx.y + s(20))
    cairo_show_text(cr, text_str)

    -- Data fallback
    local iface = resolve_iface(ctx)

    local up_now, down_now = 0, 0
    local up_total, down_total = "0 B", "0 B"

    if iface then
        up_now   = tonumber(conky_parse('${upspeedf ' .. iface .. '}')) or 0
        down_now = tonumber(conky_parse('${downspeedf ' .. iface .. '}')) or 0

        up_total   = conky_parse('${totalup ' .. iface .. '}')
        down_total = conky_parse('${totaldown ' .. iface .. '}')
    end

    local function format(v)
        return v >= 1024 and string.format("%.1f MB/s", v/1024)
                          or string.format("%.0f KB/s", v)
    end

    -- LABEL
    cairo_set_font_size(cr, s(LABEL_SIZE))

    cairo_move_to(cr, ctx.x + s(UP_X), ctx.y + s(UP_Y))
    cairo_show_text(cr, "Up Speed")

    cairo_move_to(cr, ctx.x + s(UP_TOTAL_X), ctx.y + s(UP_TOTAL_Y))
    cairo_show_text(cr, "Total Upload")

    cairo_move_to(cr, ctx.x + s(DOWN_X), ctx.y + s(DOWN_Y))
    cairo_show_text(cr, "Down Speed")

    cairo_move_to(cr, ctx.x + s(DOWN_TOTAL_X), ctx.y + s(DOWN_TOTAL_Y))
    cairo_show_text(cr, "Total Download")

    -- VALUE
    cairo_select_font_face(cr, VALUE_FONT, CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD)
    cairo_set_font_size(cr, s(VALUE_SIZE))

    -- UP
    do
        local r,g,b,_ = rgb_to_r_g_b(theme[color_map.up] or theme.red,1)
        cairo_set_source_rgba(cr,r,g,b,1)

        cairo_move_to(cr, ctx.x + s(UP_X), ctx.y + s(UP_VAL_Y))
        cairo_show_text(cr, format(up_now))

        cairo_move_to(cr, ctx.x + s(UP_TOTAL_X), ctx.y + s(UP_TOTAL_VAL_Y))
        cairo_show_text(cr, up_total)
    end

    -- DOWN
    do
        local r,g,b,_ = rgb_to_r_g_b(theme[color_map.down] or theme.blue,1)
        cairo_set_source_rgba(cr,r,g,b,1)

        cairo_move_to(cr, ctx.x + s(DOWN_X), ctx.y + s(DOWN_VAL_Y))
        cairo_show_text(cr, format(down_now))

        cairo_move_to(cr, ctx.x + s(DOWN_TOTAL_X), ctx.y + s(DOWN_TOTAL_VAL_Y))
        cairo_show_text(cr, down_total)
    end
end

-- =====================================================
-- Main
-- =====================================================
function M.draw(ctx)
    M.draw_rect(ctx)
    M.draw_graph(ctx)
    M.draw_text(ctx)
end

return M
