-- =====================================================
--  Battery Ring Card (Elysium 1x1 Final)
-- =====================================================

local M = {}

-- =====================================================
-- Config
-- =====================================================
local CARD_W = 134
local CARD_H = 134
local RADIUS = 15

local RING_X = 40
local RING_Y = 40
local RING_RADIUS = 24
local RING_THICKNESS = 7

local CRITICAL = 20

-- =====================================================
-- Helper
-- =====================================================
local function rgb_to_r_g_b(colour, alpha)
    if type(colour) == "string" then
        colour = tonumber(colour:gsub("#","0x"))
    end
    return ((colour / 0x10000) % 0x100) / 255.,
           ((colour / 0x100) % 0x100) / 255.,
           (colour % 0x100) / 255.,
           alpha
end

local function rounded_rect(cr, x, y, w, h, r)
    if r > h/2 then r = h/2 end
    if r > w/2 then r = w/2 end

    cairo_new_sub_path(cr)
    cairo_arc(cr, x + w - r, y + r, r, -math.pi/2, 0)
    cairo_arc(cr, x + w - r, y + h - r, r, 0, math.pi/2)
    cairo_arc(cr, x + r, y + h - r, r, math.pi/2, math.pi)
    cairo_arc(cr, x + r, y + r, r, math.pi, 3*math.pi/2)
    cairo_close_path(cr)
end

-- =====================================================
-- Base
-- =====================================================
function M.draw_rect(ctx)

    local cr    = ctx.cr
    local s     = ctx.s
    local theme = ctx.theme

    local r,g,b,a = rgb_to_r_g_b(theme.bg_alt, 1)

    cairo_set_source_rgba(cr, r,g,b,a)
    rounded_rect(cr, ctx.x, ctx.y,
        s(CARD_W), s(CARD_H), s(RADIUS))
    cairo_fill(cr)
end

-- =====================================================
-- Visual
-- =====================================================
function M.draw_visual(ctx)

    local cr    = ctx.cr
    local s     = ctx.s
    local ox    = ctx.x
    local oy    = ctx.y
    local theme = ctx.theme

    local rt = ctx.runtime or {}
    local real = rt.battery_percent or 0
    local charging = (rt.battery_status == "CHARGING")

    -- Blink (+3%)
    local display = real
    if charging then
        local t = os.time()
        if (t % 2) == 0 then
            display = real + 2
        end
    end

    display = math.min(display, 100)

    local pct = math.max(0, math.min(display / 100, 1))

    local x = ox + s(RING_X)
    local y = oy + s(RING_Y)

    local radius    = s(RING_RADIUS)
    local thickness = s(RING_THICKNESS)

    local angle_0 = -math.pi/2
    local angle_f = 3*math.pi/2
    local angle_v = angle_0 + (angle_f - angle_0) * pct

    cairo_set_line_width(cr, thickness)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)

    -- Background
    local r,g,b,a = rgb_to_r_g_b(theme.bar_bg_alt,1)
    cairo_set_source_rgba(cr, r,g,b,a)
    cairo_arc(cr, x, y, radius, angle_0, angle_f)
    cairo_stroke(cr)

    -- Color
    local color
    if charging then
        color = theme.yellow
    elseif real < CRITICAL then
        color = theme.red
    else
        color = theme.green
    end

    r,g,b,a = rgb_to_r_g_b(color,1)
    cairo_set_source_rgba(cr, r,g,b,a)
    cairo_arc(cr, x, y, radius, angle_0, angle_v)
    cairo_stroke(cr)
end

-- =====================================================
-- Text
-- =====================================================
function M.draw_text(ctx)

    local cr    = ctx.cr
    local s     = ctx.s
    local ox    = ctx.x
    local oy    = ctx.y
    local theme = ctx.theme

    local rt = ctx.runtime or {}
    local value = rt.battery_percent or 0

    -- Icon
    cairo_select_font_face(cr,"MaterialDesignIconsDesktop",
        CAIRO_FONT_SLANT_NORMAL,
        CAIRO_FONT_WEIGHT_NORMAL)

    cairo_set_font_size(cr, s(20))

    local r,g,b,a = rgb_to_r_g_b(theme.text_alt,1)
    cairo_set_source_rgba(cr, r,g,b,a)

    local icon = "󰌢"
    local x = ox + s(RING_X)
    local y = oy + s(RING_Y)

    local ext = cairo_text_extents_t:create()
    cairo_text_extents(cr, icon, ext)

    cairo_move_to(cr,
        math.floor(x - ext.width/2),
        math.floor(y + ext.height/2))

    cairo_show_text(cr, icon)

    -- Percentage (bottom-left)
    cairo_select_font_face(cr,"Roboto",
        CAIRO_FONT_SLANT_NORMAL,
        CAIRO_FONT_WEIGHT_BOLD)

    cairo_set_font_size(cr, s(28))

    r,g,b,a = rgb_to_r_g_b(theme.text_alt,1)
    cairo_set_source_rgba(cr, r,g,b,a)

    local text = string.format("%d%%", value)

    local tx = ox + s(14)
    local ty = oy + s(118)

    cairo_move_to(cr, tx, ty)
    cairo_show_text(cr, text)
end

-- =====================================================
-- Main
-- =====================================================
function M.draw(ctx)
    M.draw_rect(ctx)
    M.draw_visual(ctx)
    M.draw_text(ctx)
end

return M
